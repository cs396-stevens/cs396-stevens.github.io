#include <stdio.h>
#include <stdint.h>

/* can't use "sp" because gcc doesn't like it */
uint64_t sp_;
uint64_t bp_;
uint64_t rip_;
uint64_t sfp_;

void smashed(void)
{
	char buf[1024];
	asm volatile ("mov %0, rsp" : "=r"(sp_) );
	asm volatile ("mov %0, rbp" : "=r"(bp_) );
	printf("rsp=%p\nrbp=%p\n", sp_, bp_);
	printf("buf=%p\n", (uint64_t)buf);
	fflush(stdout);
	fread(buf, 1040, 1, stdin);
	asm volatile ("mov %0, QWORD PTR [rbp]"   : "=r"(sfp_) );
	asm volatile ("mov %0, QWORD PTR [rbp+8]" : "=r"(rip_) );
	printf("rip=%p\nsfp=%p\n", rip_, sfp_);
	fflush(stdout);
}

int main(int argc, char **argv)
{
	char padding[2048];
	smashed();
	return 0;
}

