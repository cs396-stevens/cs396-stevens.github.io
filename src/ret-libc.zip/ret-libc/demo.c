#include <stdio.h>
#include <stdlib.h>

void do_nothing(char * buf)
{
    // do nothing
    return;
}

void vulnerable(void)
{
    char buf[64];
    gets(buf);
    do_nothing(buf+88);
}

int main(int argc, char **argv)
{
    char padding[64];
    printf("%p\n", system);
    vulnerable();
    system("echo \"hello world\n\"");
}