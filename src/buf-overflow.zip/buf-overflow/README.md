# buffer overflow example

to make this similar to working in pwn.college, i needed to run the examples in a docker container with amd64 architecture (i have a macbook m1 pro).

i used `colima`, which wraps qemu and provides a backend (kernel) for docker.
the commands i used are in `docker.sh`.
i provisioned the docker container after entering it as follows:
```bash
cd /usr/src/project
./provision.sh
```

