#!/bin/bash

# colima start x86_64 --arch x86_64 --vm-type=vz --vz-rosetta
docker run --rm -it \
	-v "$(pwd)":/usr/src/project \
	--privileged \
	--security-opt seccomp=unconfined \
	--entrypoint /bin/bash \
	debian:bookworm
