#include <signal.h>
#include <stdio.h>
#include <string.h>

int main()
{
    char realPassword[20];
    char givenPassword[20];

    strncpy(realPassword, "secretpwd1111111111", 20);
    gets(givenPassword);
    
    if (0 == strncmp(givenPassword, realPassword, 20)) {
        printf("SUCCESS!\n");
    } else {
        printf("FAILURE!\n");
    }

    printf("realPassword: %s\n", realPassword);
    printf("givenPassword: %s\n", givenPassword);
    printf("realPassword   addr: %p\n", (void *)realPassword);
    printf("givenPassword       addr: %p\n", (void *)givenPassword);

    return 0;
}