#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

static inline void sleep_ms(int ms)
{
    static struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000;
    nanosleep(&ts, NULL);
}

int main(int argc, char ** argv)
{
    srand(time(NULL));

    const int NCHILD = 2;
    const long LOOPS = 50;

    // create shared mapping
    int *counter = (int *) mmap(
        NULL,
        sizeof(int),
        PROT_READ | PROT_WRITE,
        MAP_SHARED | MAP_ANONYMOUS,
        -1,
        0
    );

    if (counter == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    *counter = 0;

    for (int i = 0; i < NCHILD; i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            exit(1);
        } else if (pid == 0) {
            // increment shared counter without synchronization
            for (long j = 0; j < LOOPS; j++) {
                printf("child %d reading counter\n", i);
                int tmp = *counter;
                tmp++;
                sleep_ms((rand() % 10) + 1);
                *counter = tmp;
                printf("child %d wrote counter\n", i);
            }
            exit(0);
        }
    }

    // wait for children to stop
    for (int i = 0; i < NCHILD; i++) {
        wait(NULL);
    }

    printf("expected value: %d\n", NCHILD * (int)LOOPS);
    printf("observed value: %d\n", *counter);

    // cleanup
    if (munmap(counter, sizeof(int)) == -1) {
        perror("munmap");
    }

    return 0;
}

