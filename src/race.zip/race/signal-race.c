#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>

// shared global variable
volatile int counter = 0;
volatile int fired = 0;
volatile int status = 0;

static struct itimerval period = {
    .it_interval = {
        .tv_sec = 0,
        .tv_usec = 0,
    },
    .it_value = {
        .tv_sec = 0,
        .tv_usec = 0,
    }
};

static inline void sleep_ms(int ms)
{
    static struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000;
    nanosleep(&ts, NULL);
}

// not safe for handler
void set_timer_interval(unsigned int us)
{
    period.it_value.tv_usec = us;
    if (setitimer(ITIMER_REAL, &period, NULL) < 0) {
        perror("setitimer");
        exit(1);
    }
}

void handle_sigalrm(int sig)
{
    fired = 1;
    // increment counter
    counter++;
}

#define RAND_US (((rand() % 20) + 1) * 1000)

int main(void)
{
    srand(time(NULL));

    // register handler
    if (signal(SIGALRM, handle_sigalrm) == SIG_ERR) {
        perror("signal");
        exit(1);
    }

    set_timer_interval(RAND_US);

    while (counter < 100) {
        if (fired) {
            fired = 0;
            // change next timer interval
            set_timer_interval(RAND_US);

            if (!(counter % 2)) {
                // there's a race here.
                sleep_ms(10);
                printf("counter is even: %d\n", counter);
            }
        }
    }

    return 0;
}