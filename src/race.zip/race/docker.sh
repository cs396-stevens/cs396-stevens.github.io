#!/usr/bin/env bash
docker run --rm -it -v "$(pwd)":/home/project --entrypoint /bin/bash cs396/debian:demo
