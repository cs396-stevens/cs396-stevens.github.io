#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>

static inline void sleep_ms(int ms)
{
    static struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000;
    nanosleep(&ts, NULL);
}

// globals
const char * demo_path = "/tmp/demo.txt";
const char * target_path = "/tmp/target.txt";

void initialize(void)
{
    // initialize state by deleting/creating files
    // if necessary
    if (access(demo_path, F_OK) == 0) {
        if (unlink(demo_path) < 0) {
            printf("initialization failed: %s\n", demo_path);
            perror("unlink");
            exit(1);
        }
    }
    int fd = -1;
    if ((fd = creat(demo_path, 0666)) < 0) {
        printf("%s\n", demo_path);
        perror("creat");
        exit(1);
    }
    if (close(fd) < 0) {
        perror("close");
        exit(1);
    }

    if ((fd = creat(target_path, 0666)) < 0) {
        printf("%s\n", target_path);
        perror("creat");
        exit(1);
    }
    const char * msg = "nothing to see here...\n";
    if (write(fd, msg, strlen(msg)) < 0) {
        printf("%s\n", target_path);
        perror("write");
        exit(1);
    }
    if (close(fd) < 0) {
        perror("close");
        exit(1);
    }
}

void child(void)
{
    // the child will try to swap out
    // the file from under the parent
    unsigned int delay_ms = (rand() % 5) + 1;
    sleep_ms(delay_ms);

    if (unlink(demo_path) < 0) {
        perror("unlink");
        exit(1);
    }

    if (symlink(target_path, demo_path) < 0) {
        perror("symlink");
        exit(1);
    }

    exit(0);
}

int parent(void)
{
    // the parent will write something to demo_path
    unsigned int delay_ms = (rand() % 10) + 1;

    if (access(demo_path, W_OK) != 0) {
        perror("access");
        return 1;
    }

    // sleep random amount of time
    // should make race more likely
    sleep_ms(delay_ms);

    int fd = -1;
    if ((fd = open(demo_path, O_WRONLY)) < 0) {
        perror("open");
        return 1;
    }

    const char * msg = "shhh! secret!\n";
    if (write(fd, msg, strlen(msg)) < 0) {
        perror("write");
        close(fd);
        return 1;
    }

    printf("wrote to file: %s\n", demo_path);
    close(fd);
    return 0;
}


int main(int argc, char ** argv)
{
    int retval = 0;
    pid_t pid;

    srand(time(NULL));

    initialize();

    if ((pid = fork()) < 0) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) {
        // child process
        child();
    } else {
        // parent process
        retval = parent();
    }

    wait(NULL);
    return retval;
}