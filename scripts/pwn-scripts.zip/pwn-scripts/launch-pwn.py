#!/run/dojo/bin/python3
import os
import argparse
import shlex
import subprocess
from pathlib import Path
from IPython import embed

# # pwntools/gdb relies on this environment variable being set
# # when used over ssh
# if not 'TERM' in os.environ or os.environ['TERM'] != "xterm-256color":
#     os.environ['TERM'] = "xterm-256color"

# configure pwntools not to automatically update
if not (_pwn_config := Path("~/.config/.pwn.conf").expanduser()).exists():
    _pwn_config.parent.mkdir(exist_ok=True, parents=True)
    with open(_pwn_config, 'a') as f:
        f.write("\n[update]\ninterval=never\n")

from pwn import *

"""
launches a pwntools session with target binary
"""

context.terminal = ['tmux', 'splitw', '-h']

cheatsheet = """\
pwntools:
- documentation: https://docs.pwntools.com/en/stable/
- interaction: https://docs.pwntools.com/en/stable/intro.html#making-connections

tmux:
`CTRL-B` + `?`          show all tmux shortcuts
`CTRL-B` + `o`          swap panes
`CTRL-B` + `<arrows>`   move to pane
`CTRL-B` + `[`          enter copy mode (scrolling)

more: https://gist.github.com/MohamedAlaa/2961058
"""

_parser = argparse.ArgumentParser(prog='launch-pwn', description=__doc__)
_parser.add_argument('target', type=Path,
    help="path to target binary")
_parser.add_argument('--no-gdb', dest='gdb', action='store_false', default=True,
    help="do not launch gdb session")

_args = _parser.parse_args()
target = _args.target

_gdbscript = """\
set disassembly-flavor intel
set pagination off
"""

assert target.exists(), \
    "target does not exist: {}".format(str(target))
assert 'TMUX' in os.environ, \
    "you should be running this in tmux"

if _args.gdb:
    p = gdb.debug(str(target), aslr=False, gdbscript=_gdbscript)
else:
    p = process(str(target))

# helper functions

TIMEOUT = 3 # default 3 second timeout
recv = lambda: print(p.recv(timeout=TIMEOUT).decode('utf-8'))
sh = lambda cmd: subprocess.run(shlex.split(cmd))

print(f"""\
predefined globals:

from pwn import *

cheatsheet # print this for some helpful links/shortcuts
target  = {repr(target)}
p       = {repr(p)}
TIMEOUT = {TIMEOUT} # (seconds)
recv    = lambda: print(p.recv(timeout=TIMEOUT).decode('utf-8'))
sh      = lambda cmd: subprocess.run(shlex.split(cmd))

""")

# p.interactive() # keeps script alive but no interpeter
embed() # drop into interpreter
