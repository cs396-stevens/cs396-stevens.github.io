from math import ceil

del __builtins__.pow

"""
Starter code for rsa implementation problem.

INSTRUCTIONS:

- Complete indicated functions.

- You may implement helper functions as needed.

- You may NOT import anything from non-standard libraries other than what has
  already been provided above.

- You may NOT use the built-in `pow` function.

- You may NOT change the names or parameters of any classes, methods, and/or
  functions provided by this starter code.

"""

### HELPER FUNCTIONS

def to_bytes(v: int):
    return v.to_bytes(ceil(v.bit_length() / 8), 'little')


### RSA FUNCTIONS


def modexp(base: int, exp: int, mod: int):
    """
    compute the modular exponentiation of the base raised to the exponent
    relative to mod
    
    :param      base:  The base
    :type       base:  int
    :param      exp:   The exponent
    :type       exp:   int
    :param      mod:   The modifier
    :type       mod:   int
    """
    # BEGIN TODO
    result = 0


    # END TODO

    return result

def gen_private(e: int, p: int, q: int):
    """
    returns a corresponding private key for the given public key.
    the private key must not be negative.
    
    :param      e:    The public key e
    :type       e:    int
    :param      p:    The prime p
    :type       p:    int
    :param      q:    The prime q
    :type       q:    int
    """
    # BEGIN TODO
    d = 0

    # END TODO

    return d

def keygen(p: int, q: int):
    """
    generates the public and private keys given p and q
    
    :param      p:    The prime p
    :type       p:    int
    :param      q:    The prime q
    :type       q:    int
    """
    # BEGIN TODO
    e, d, N = 0, 0, 0
    

    # END TODO
    
    return e, d, N

def enc(msg: bytes | bytearray, e: int, N: int):
    """
    encrypts a bytestring message.
    assume that the msg when converted to an integer is less than N
    
    :param      msg:  The message
    :type       msg:  bytes-like
    :param      e:    The public key exponent
    :type       e:    int
    :param      N:    The public key modulus
    :type       N:    int
    """
    # BEGIN TODO
    ciphertext = b''

    # END TODO

    return ciphertext

def dec(cip: bytes | bytearray, d: int, N: int):
    """
    decrypts a ciphertext bytestring.
    assume that the ciphertext when converted to an integer is less than N
    
    :param      cip:  The ciphertext
    :type       cip:  bytes-like
    :param      d:    The private key exponent
    :type       d:    int
    :param      N:    The public key modulus
    :type       N:    int
    """
    # BEGIN TODO
    msg = b''

    # END TODO

    return msg



if __name__ == "__main__":
    # run test cases when run as a script
    tests = [
        {
            "p": 9818778348106354056511238014562946215808557153912571240846809204950188910364095168022289590746974832976402646532914705090338958199120253340738243190989563,
            "q": 9999916639467043171695444774011920398941633665692625446075667838296007518106114755385623420062498653608530391053308103605431488918702109835347186311287597,
            "msg": "68656c6c6f20776f726c64000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
            "cip": "8c8b4258ac24857a35a6a1b1bb651df928d18017be97fede85b4a033d7499a5b54db9b6bc25f78ae044e02f02746305f0f41693351e341bc330d412a23bcf9a3c2d86bb5c16a1c885548d552cf3d0f925e2ec688730741712013ea8b857a2a15467283f1be359196af9151245f09a028017f31a88f47a47a5de880c56a33c155"
        },
        {
            "p": 11275624884440529622827701045370893415545772096306586919941559807526145881167682612682789272936018043792918441545477431783458041450810430820135472889383857,
            "q": 13257231744690373750425406125956783716138345831604392745457782375774999853496856988099823030115613857881882551786705744222255775167623076002405259314753687,
            "msg": "74686520717569636b2062726f776e20666f78206a756d706564206f76657220746865206c617a7920646f67000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
            "cip": "169f3704bace1cd87890df1b190393d6048f82734d82c5a9baaf9120e3b88197a5c0d41f6bbd6546048fae83896c870075d85e6f77eb582685e1634beb45573afc5c02aeb24c6181d1bf34b5a67cd86e5777c9f190c57a3f09e30b2ae02f3cdd457784d1a1fd9ff7e7b798d4bdd0e39d7a130601af27b4b7f32cbd0e6374b932"
        },
        {
            "p": 11421538666965692352390439493356742756870119393626305919320295476137013088034369950529682203728104794960316242182108019407639229067423265257081577936755297,
            "q": 12842467177514459335665095228545284188303013085660318305567913875322081568505397054662569647649404788089491281716109772258400395706372290657824201317144179,
            "msg": "23696e636c756465203c737464696f2e683e0a696e74206d61696e28766f6964290a7b0a20207072696e7466282268656c6c6f20776f726c64210a22293b0a7d0a000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
            "cip": "10bf13a1eb9c1e19e112c15515e5ca4c0e0b85e668a331981411a7e282ea9470e945ec713cc2fcaa7e432e2b739ea09c48fb74bacc13f71a04296db0b5ba0e7b700f160de2e3148296bb9496d474de4756a5a29274bee9b6b1feb35b65f2e83ee909ec3fed2d94201d7f6733970f43be98dc2c7b66552025b12f8699a2308ac0"
        },
        {
            "p": 174288228981491049579456129489040119596529499649772690597514295486404726660070965807512591451447084493798248658215991779958751420242968995883245964411789814842869827307740278404722007528313017394995443186637168871955258553574197983859772594167952984725006289964865492656222866700259904129807502069987915036363,
            "q": 178211037641767929338577678033082973446954361093774078409317111656065814729688028853522445145951155647855468733151215115330859422491117734193238403013607881870238249453671635838140277467850093358395262501360036422247334450702658535973490971453256841266051397113847667108081502466330945563145292823191645950079,
            "msg": "7423b9d92a5fcd034be6d91c16d544689e4a050e73d06e0963fdad69b455f4e09aec5a65fb34403519ab80530a4433a688a560f39fe3a4a57a172319bd3587bb1fc4c2cc42a558d829963e53c104c6d1f2b648b30c07c2a7704faf0ab77671be105a7bdbc932f66990fd8cda1d0b46fb5070b7cb8e003824f467fffbc618dfd45fe9ca30d17074c7731325f78490aa58c203a8833bb22538b215089b07954868ac12810b8d42f7aa08eddada66aaec54fcb32d25bd95b67bf81f7bc485d55d227a5321fb446f2dae6098e49709620e4120dcfd4052fb975b72573222c51c4d91ba2597238a28af900e4540c09f0fe7f769c1d5b17a066c5c817583f46e8b6800",
            "cip": "41ce38b9073169ef8e8297f106bf026da0b5ea38980184ce948000a3fedffa767bda7e8636590779f10eb275b821047e53b56a9bcd166395f0e2ee69c2fcb916527854ebcbd927e0d6c6674943d82a20a26cda8abc4cb268006129daa7a76455d4d9add8ed1ae8429b50f7b4608e135ce46e4fd92c289beefe14c06a11d13ae4883472de7b601a3f151496999f21943eaf170e0354996238d8a5db6f7701c3fc1ab62fb2e049fcc84b2c66b7ec8934b397468ed3196527a5a3676c4affc784ae49a6718b1a162b9f1969a670ed54baac6c114679d7eed278b3b2e1bcec5b4ed3929c7999dc4a6702f6070b1cb8d0833d7da0ff1154c9d6ed0402f82d3716b334"
        },
    ]

    for i, t in enumerate(tests):
        p, q = t['p'], t['q']
        msg, cip = bytes.fromhex(t['msg']), bytes.fromhex(t['cip'])
        e, d, N = keygen(p, q)
        tcip = enc(msg, e, N)
        tmsg = dec(cip, d, N)
        if cip == tcip and msg == tmsg:
            print(f"\x1b[32mtest {i} passed!\x1b[0m")
            continue

        print(f"\x1b[31mtest {i} failed!\x1b[0m")
        print(f"expected cip:\n{cip.hex()}")
        print(f"got cip:\n{tcip.hex()}")
        print(f"expected msg:\n{msg.hex()}")
        print(f"got msg:\n{tmsg.hex()}")
