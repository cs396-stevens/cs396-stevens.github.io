from Crypto.Util.Padding import pad, unpad
from Crypto.Util.strxor import strxor
from Crypto.Cipher import AES

"""
Starter code for cbc-mac problem.

INSTRUCTIONS:

- Complete the CBCMAC class below.

- You will use AES as your block cipher with block size 16.
  A block cipher can be used in place of the pseudorandom function we discussed
  in class, since they are themselves based on pseudorandom functions.

- You may implement helper methods, class variables, and instance variables on
  the MAC class as needed.

- You may NOT import anything from non-standard libraries other than what has
  already been provided above

- You may NOT change the names or parameters of any classes, methods, and/or
  functions provided by this starter code.

"""


class CBCMAC():
    def __init__(self, key: bytes):
        """
        Initializes the MAC scheme. Analagous to the Gen algorithm
        discussed in K&L Ch. 4
        
        :param      key:  The key
        :type       key:  bytes
        """
        assert isinstance(key, (bytes, bytearray)) and len(key) == 16

        # note that we should only ever be giving inputs that correspond
        # to the block length, and we are implementing CBC ourselves,
        # so the cipher mode given to AES does not matter.
        self.cipher = AES.new(key,  mode=AES.MODE_ECB)

        # BEGIN TODO: any other initialization you may need


        # END TDOD

    def mac(self, msg: bytes):
        """
        takes an input message of arbitrary length and returns the corresponding
        CBC-MAC tag t.
        you may assume that the length of the message will be less than 2^128.
        
        :param      msg:    The message
        :type       msg:    bytes
        """
        tag = b''

        # BEGIN TODO


        # END TODO

        return tag

    def verify(self, msg: bytes, tag: bytes):
        """
        takes the message and MAC tag and returns true if the CBC-MAC tag
        is valid for the given message.
        returns false otherwise.
        
        :param      msg:    The message
        :type       msg:    bytes
        :param      tag:  The tag
        :type       tag:  bytes
        """
        isvalid = False 

        # BEGIN TODO


        # END TODO

        return isvalid



if __name__ == "__main__":
    def run_test(i, key, msg, tag, valid):
        key = bytes.fromhex(key)
        msg = bytes.fromhex(msg)
        tag = bytes.fromhex(tag)

        cbcmac = CBCMAC(key)
        ttag = cbcmac.mac(msg)
        tvalid = cbcmac.verify(msg, tag)

        if tvalid == valid:
            print(f"\x1b[32mtest {i} passed!\x1b[0m")
        else:
            print(f"\x1b[31mtest {i} failed!\x1b[0m")
            print(f"expected tag:\n{tag.hex()}")
            print(f"got tag:\n{ttag.hex()}")

    tests = [
        {
            "key": "e0522c52c548727fb181380b3b3cf8a3",
            "msg": "68656c6c6f20776f726c64",
            "tag": "76c9d2cdc43522cb88114d0193cc9412",
            "valid": True
        },
        {
            "key": "137dc5fae82c3db6c63dd4869bc2ed9f",
            "msg": "68656c6c6f20776f726c64000000",
            "tag": "cc68a3759f18d5e57bc02bffd3d9d7fb",
            "valid": True
        },
        {
            "key": "3ed8c8b4082fe73d1df656d2f562577f",
            "msg": "74686973206973206e6f7420612068696464656e20746573742063617365",
            "tag": "72435c00fba5485ffca642008d5cf6a3",
            "valid": True
        },
        {
            "key": "da7ef73d0e4ce74b95b12464c6dc1be7",
            "msg": "796f752073686f756c642070726f6261626c792074727920636f6e737472756374696e67206120666f72676572792061747461636b206173206120746573746261736564206f6e20796f757220736f6c7574696f6e20746f20746865206c6173742070617274206f662074686973207175657374696f6e2e",
            "tag": "64643bb480d2b9f6798e6c4ad419f39d",
            "valid": True
        },
        {
            "key": "a8970403f3a6b71f86e3bf2302503f1a",
            "msg": "696e20706172746963756c6172207765276c6c2074727920746f207472697020796f75207570207769746820666f72676572792061747461636b732074686174206172656b6e6f776e20746f20776f726b20616761696e73742074686520434243204d414320696d706c656d656e746174696f6e20746861742063686f6f7365732049563d30",
            "tag": "de421c413bc6dc65fb32d290420487af",
            "valid": False
        },
    ]


    for i, test in enumerate(tests):
        run_test(i, **test)
        